const productName = "Холодильник";
let productCount = 9;
const productCategory = "Бытовая техника";
let productCost = 33000;

console.log('productName: ', productName);

console.log(productCount * productCost);